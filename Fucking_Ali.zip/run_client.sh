gcc -o client.out client.c -lpthread -w
./client.out