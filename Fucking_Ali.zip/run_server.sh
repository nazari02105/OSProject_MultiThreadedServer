gcc -o server.out server.c -lpthread -w
./server.out
